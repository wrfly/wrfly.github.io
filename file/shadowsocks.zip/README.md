Shadowsocks client for linux.

1.Put the config.json and the shadowsocks in the same folder.
2.Run the commond $./shadowsocks &
3.Down